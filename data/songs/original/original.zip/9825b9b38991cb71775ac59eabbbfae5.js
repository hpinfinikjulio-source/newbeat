p=1.4,
a=(a,b,c)=>(t*2**(parseInt(a[(t>>b)%a.length],36)/12-p)/c&32)/1.5-12,
b=(a,b,c)=>t*2**(parseInt(a[(t>>b)%a.length],36)/12-p)*PI/32/c,n=8192,
(
a(e='998D',16,2)+
a('DDBG',16,2)+
a('KKIN',16,2)+sin(b(e,16,8)+sin(b(e,16,8)))*32
)*'1101101101101100'[15&t>>12]+sin(cbrt(t%16384+16)*8)*(1-t%n/n)*!(t&n)*48