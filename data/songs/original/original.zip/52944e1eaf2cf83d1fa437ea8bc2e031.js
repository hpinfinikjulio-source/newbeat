a=[1,2,3,4,0.8,1.6,2.4,3.2],
a=a[(t>>14)%a.length]/2,

sum(10,"sin(t/x*i/16*a+x*PI)/2 ")/(10+(t>>11)%32)
function sum(i,s){
o = 0;
for(x=1;x<i;x++){
o+=eval(s)
}
return o;
}